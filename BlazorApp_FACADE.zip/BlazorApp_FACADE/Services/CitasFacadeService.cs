﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Collections.Generic;
using System.Threading.Tasks;
using BlazorApp_FACADE.Models;

namespace BlazorApp_FACADE.Services
{
    public class CitasFacadeService
    {
        private readonly HttpClient _httpClient;

        public CitasFacadeService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<Paciente>> ObtenerPacientes()
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<List<Paciente>>("api/pacientes") ?? new List<Paciente>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error obteniendo pacientes: {ex.Message}");
                return new List<Paciente>();
            }
        }

        public async Task<List<Medico>> ObtenerMedicos()
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<List<Medico>>("api/medicos") ?? new List<Medico>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error obteniendo médicos: {ex.Message}");
                return new List<Medico>();
            }
        }

        public async Task<List<Cita>> ObtenerCitas()
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<List<Cita>>("api/citas") ?? new List<Cita>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error obteniendo citas: {ex.Message}");
                return new List<Cita>();
            }
        }

        public async Task<bool> AgregarPaciente(Paciente paciente)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("api/pacientes", paciente);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error agregando paciente: {ex.Message}");
                return false;
            }
        }

        public async Task<bool> AgregarMedico(Medico medico)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("api/medicos", medico);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error agregando médico: {ex.Message}");
                return false;
            }
        }

        public async Task<bool> AgregarCita(Cita cita)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("api/citas", cita);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error agregando cita: {ex.Message}");
                return false;
            }
        }

        public async Task<bool> EliminarPaciente(int id)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"api/pacientes/{id}");
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error eliminando paciente: {ex.Message}");
                return false;
            }
        }

        public async Task<bool> EliminarMedico(int id)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"api/medicos/{id}");
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error eliminando médico: {ex.Message}");
                return false;
            }
        }

        public async Task<bool> EliminarCita(int id)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"api/citas/{id}");
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error eliminando cita: {ex.Message}");
                return false;
            }
        }
    }
}
